# NN Tech Wordle Game - Setup Script for Windows
# This script automates the setup process for the Wordle game project
# Simply run this script from the project directory
# Usage: .\setup.ps1
# OR: powershell -ExecutionPolicy Bypass -File setup.ps1

# Set error action preference
$ErrorActionPreference = "Stop"

# Color functions
function Write-Header {
    param([string]$Message)
    Write-Host "`n========================================" -ForegroundColor Blue
    Write-Host $Message -ForegroundColor Blue
    Write-Host "========================================`n" -ForegroundColor Blue
}

function Write-Success {
    param([string]$Message)
    Write-Host "✓ $Message" -ForegroundColor Green
}

function Write-Error-Custom {
    param([string]$Message)
    Write-Host "✗ $Message" -ForegroundColor Red
}

function Write-Info {
    param([string]$Message)
    Write-Host "ℹ $Message" -ForegroundColor Yellow
}

# Check prerequisites
function Check-Prerequisites {
    Write-Header "Checking Prerequisites"

    # Check Node.js
    try {
        $nodeVersion = node --version
        Write-Success "Node.js installed: $nodeVersion"

        # Extract major version number
        $majorVersion = [int]($nodeVersion -replace '[^0-9]', '' | Select-String -Pattern '^[0-9]+' | ForEach-Object { $_.Matches[0].Value })

        if ($majorVersion -lt 16) {
            Write-Error-Custom "Node.js version 16 or higher is required (you have v$majorVersion)"
            Write-Host "Please upgrade Node.js to version 16 or higher (v22 recommended)" -ForegroundColor Yellow
            Write-Host "Download from: https://nodejs.org/" -ForegroundColor Yellow
            Write-Host "Or use: choco install nodejs --version=22.0.0" -ForegroundColor Yellow
            exit 1
        }
    }
    catch {
        Write-Error-Custom "Node.js is not installed!"
        Write-Host "Please install Node.js from https://nodejs.org/ (version 16 or higher, v22 recommended)" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Using Chocolatey:" -ForegroundColor Yellow
        Write-Host "  choco install nodejs" -ForegroundColor Cyan
        Write-Host ""
        exit 1
    }

    # Check npm
    try {
        $npmVersion = npm --version
        Write-Success "npm installed: $npmVersion"
    }
    catch {
        Write-Error-Custom "npm is not installed!"
        exit 1
    }

    # Check Git
    try {
        $gitVersion = git --version
        Write-Success "Git installed: $gitVersion"
    }
    catch {
        Write-Error-Custom "Git is not installed!"
        Write-Host "Please install Git from https://git-scm.com/" -ForegroundColor Yellow
        exit 1
    }

    Write-Host ""
}

# Verify project structure
function Verify-Project {
    Write-Header "Verifying Project Structure"

    $packageJsonPath = Join-Path -Path "." -ChildPath "package.json"

    if (-not (Test-Path $packageJsonPath)) {
        Write-Error-Custom "package.json not found in current directory!"
        Write-Host "Please make sure you're running this script from the project root directory" -ForegroundColor Yellow
        exit 1
    }

    Write-Success "Project structure verified"
    Write-Host ""
}

# Install dependencies
function Install-Dependencies {
    Write-Header "Installing Dependencies"

    try {
        Write-Info "Running 'npm install'..."
        npm install

        Write-Success "Dependencies installed successfully"
        Write-Host ""
    }
    catch {
        Write-Error-Custom "Failed to install dependencies: $_"
        exit 1
    }
}

# Show project info
function Show-ProjectInfo {
    Write-Header "Project Setup Complete!"

    Write-Host ""
    Write-Success "NN Tech Wordle Game is ready to run"
    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor Blue
    Write-Host ""
    Write-Host "1. Start the development server:"
    Write-Host "   npm run dev" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "2. Open your browser and visit:"
    Write-Host "   http://localhost:3000" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Other available commands:" -ForegroundColor Blue
    Write-Host "   npm run build    - Create production build" -ForegroundColor Yellow
    Write-Host "   npm start        - Run production server" -ForegroundColor Yellow
    Write-Host "   npm run lint     - Run ESLint checks" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "For more information, see README.md" -ForegroundColor Blue
    Write-Host ""
}

# Main script execution
function Main {
    Write-Header "NN Tech Wordle Game - Automated Setup (Windows)"
    Write-Host "This script will set up the Wordle game project on your machine"
    Write-Host ""

    # Check prerequisites
    Check-Prerequisites

    # Verify project structure
    Verify-Project

    # Install dependencies
    Install-Dependencies

    # Show success message
    Show-ProjectInfo
}

# Run main function
Main

