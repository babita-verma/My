package com.nn.wordle.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "game_result")
public class GameResult {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "player_id", nullable = false)
    private Player player;

    @Column(name = "game_day", nullable = false)
    private LocalDate gameDay;

    @Column(name = "game_time", nullable = false)
    private LocalTime gameTime;

    @Column(name = "score", nullable = false)
    private Long score;

    @Column(name = "guessed", nullable = false)
    private boolean guessed;

    public GameResult() {
    }

    public GameResult(Player player, LocalDate gameDay, LocalTime gameTime, Long score, boolean guessed) {
        this.player = player;
        this.gameDay = gameDay;
        this.gameTime = gameTime;
        this.score = score;
        this.guessed = guessed;
    }

    public void updateGameResult(LocalTime gameTime, Long score, boolean guessed) {
        this.gameTime = gameTime;
        this.score = score;
        this.guessed = guessed;
    }

    public Long getScore() {
        return score;
    }

    public Player getPlayer() {
        return player;
    }

}