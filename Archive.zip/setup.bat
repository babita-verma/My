@echo off
REM NN Tech Wordle Game - Setup Script for Windows (Batch)
REM This script automates the setup process for the Wordle game project
REM Simply run this script from the project directory
REM Usage: setup.bat

setlocal enabledelayedexpansion

REM Colors using ANSI codes (Windows 10+)
for /F %%A in ('echo prompt $E ^| cmd') do set "ESC=%%A"
set "RED=%ESC%[91m"
set "GREEN=%ESC%[92m"
set "YELLOW=%ESC%[93m"
set "BLUE=%ESC%[94m"
set "NC=%ESC%[0m"

echo.
echo %BLUE%========================================%NC%
echo %BLUE%NN Tech Wordle Game - Automated Setup%NC%
echo %BLUE%========================================%NC%
echo.
echo This script will set up the Wordle game project on your machine
echo.

REM Check prerequisites
call :check_prerequisites

REM Verify project structure
call :verify_project

REM Install dependencies
call :install_dependencies

REM Show project info
call :show_project_info

echo.
pause
exit /b 0

REM Functions

:check_prerequisites
echo %BLUE%========================================%NC%
echo %BLUE%Checking Prerequisites%NC%
echo %BLUE%========================================%NC%
echo.

REM Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo %RED%Error: Node.js is not installed!%NC%
    echo Please install Node.js from https://nodejs.org/ ^(version 16 or higher, v22 recommended^)
    echo.
    echo Using Chocolatey:
    echo   choco install nodejs
    echo.
    echo Or visit: https://nodejs.org/
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('node --version') do set NODE_VERSION=%%i
echo %GREEN%[OK] Node.js installed: !NODE_VERSION!%NC%

REM Check Node.js version is 16 or higher
for /f "tokens=1,2 delims=v." %%a in ("!NODE_VERSION!") do (
    set NODE_MAJOR=%%a
)
if !NODE_MAJOR! lss 16 (
    echo %RED%Error: Node.js version 16 or higher is required ^(you have v!NODE_MAJOR!^)%NC%
    echo Please upgrade Node.js to version 16 or higher ^(v22 recommended^)
    echo Visit: https://nodejs.org/
    echo.
    pause
    exit /b 1
)

REM Check npm
where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo %RED%Error: npm is not installed!%NC%
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('npm --version') do set NPM_VERSION=%%i
echo %GREEN%[OK] npm installed: !NPM_VERSION!%NC%

echo.
exit /b 0

:verify_project
echo %BLUE%========================================%NC%
echo %BLUE%Verifying Project Structure%NC%
echo %BLUE%========================================%NC%
echo.

if not exist "package.json" (
    echo %RED%Error: package.json not found in current directory!%NC%
    echo Please make sure you're running this script from the project root directory
    echo.
    pause
    exit /b 1
)

echo %GREEN%[OK] Project structure verified%NC%
echo.
exit /b 0

:install_dependencies
echo %BLUE%========================================%NC%
echo %BLUE%Installing Dependencies%NC%
echo %BLUE%========================================%NC%
echo.

echo %YELLOW%[INFO] Running 'npm install'...%NC%
call npm install

if %errorlevel% neq 0 (
    echo %RED%Error: Failed to install dependencies%NC%
    echo.
    pause
    exit /b 1
)

echo %GREEN%[OK] Dependencies installed successfully%NC%
echo.
exit /b 0

:show_project_info
echo %BLUE%========================================%NC%
echo %BLUE%Project Setup Complete!%NC%
echo %BLUE%========================================%NC%
echo.
echo %GREEN%[OK] NN Tech Wordle Game is ready to run%NC%
echo.
echo %BLUE%Next Steps:%NC%
echo.
echo 1. Start the development server:
echo    %YELLOW%npm run dev%NC%
echo.
echo 2. Open your browser and visit:
echo    %YELLOW%http://localhost:3000%NC%
echo.
echo %BLUE%Other available commands:%NC%
echo    %YELLOW%npm run build%NC%    - Create production build
echo    %YELLOW%npm start%NC%        - Run production server
echo    %YELLOW%npm run lint%NC%     - Run ESLint checks
echo.
echo %BLUE%For more information, see README.md%NC%
echo.
exit /b 0

