param(
    [string]$Conference = "NN-GUILD",
    [switch]$SkipTests,
    [switch]$NoCache
)

$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Resolve-Path (Join-Path $scriptDir "../..")
$composeDir = Join-Path $projectRoot "infra/docker-compose"
$exportDir = Join-Path $projectRoot "docker-export-data"

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker CLI not found. Install Docker Desktop and ensure 'docker' is on PATH."
}

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    throw "Java not found. Install JDK 21 and ensure 'java' is on PATH."
}

if (-not (Test-Path $exportDir)) {
    New-Item -ItemType Directory -Path $exportDir | Out-Null
}

Write-Host "[1/3] Building backend jar..."
$gradleCmd = ".\\gradlew.bat clean jar"
if ($SkipTests) {
    $gradleCmd += " -x test"
}
cmd /c "cd /d \"$projectRoot\" && $gradleCmd"

Write-Host "[2/3] Starting containers with docker compose..."
$env:WORDLE_EXPORT_PATH = (Resolve-Path $exportDir).Path
$env:GAME_CONFERENCE = $Conference

if ($NoCache) {
    cmd /c "cd /d \"$composeDir\" && docker compose -f docker-compose.yml -f docker-compose.windows.yml build --no-cache wordle_backend"
    cmd /c "cd /d \"$composeDir\" && docker compose -f docker-compose.yml -f docker-compose.windows.yml up -d"
} else {
    cmd /c "cd /d \"$composeDir\" && docker compose -f docker-compose.yml -f docker-compose.windows.yml up -d --build"
}

Write-Host "[3/3] Done."
Write-Host "Backend:  http://localhost:8080"
Write-Host "PgAdmin:  http://localhost:8097"
Write-Host "Export dir: $exportDir"
Write-Host ""
Write-Host "To stop:"
Write-Host "cd $composeDir"
Write-Host "docker compose -f docker-compose.yml -f docker-compose.windows.yml down"

