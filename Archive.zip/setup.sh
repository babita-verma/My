#!/bin/bash

# NN Tech Wordle Game - Setup Script
# This script automates the setup process for the Wordle game project
# Simply run this script from the project directory
# Usage: ./setup.sh

set -e  # Exit on any error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_header() {
  echo -e "${BLUE}========================================${NC}"
  echo -e "${BLUE}$1${NC}"
  echo -e "${BLUE}========================================${NC}"
}

print_success() {
  echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
  echo -e "${RED}✗ $1${NC}"
}

print_info() {
  echo -e "${YELLOW}ℹ $1${NC}"
}

# Check prerequisites
check_prerequisites() {
  print_header "Checking Prerequisites"

  # Check Node.js
  if ! command -v node &> /dev/null; then
    print_error "Node.js is not installed!"
    echo "Please install Node.js from https://nodejs.org/ (version 16 or higher, v22 recommended)"
    echo ""
    echo "macOS (Homebrew):"
    echo "  brew install node@22"
    echo ""
    echo "Linux (Ubuntu/Debian):"
    echo "  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -"
    echo "  sudo apt-get install -y nodejs"
    exit 1
  fi

  NODE_VERSION=$(node --version)
  print_success "Node.js installed: $NODE_VERSION"

  # Check if Node.js version is 16 or higher
  NODE_MAJOR_VERSION=$(echo $NODE_VERSION | grep -oE '[0-9]+' | head -1)
  if [ "$NODE_MAJOR_VERSION" -lt 16 ]; then
    print_error "Node.js version 16 or higher is required (you have v$NODE_MAJOR_VERSION)"
    echo "Please upgrade Node.js to version 16 or higher (v22 recommended)"
    exit 1
  fi

  # Check npm
  if ! command -v npm &> /dev/null; then
    print_error "npm is not installed!"
    exit 1
  fi
  print_success "npm installed: $(npm --version)"

  # Check Git
  if ! command -v git &> /dev/null; then
    print_error "Git is not installed!"
    echo "Please install Git from https://git-scm.com/"
    exit 1
  fi
  print_success "Git installed: $(git --version)"

  echo ""
}

# Verify project structure
verify_project() {
  print_header "Verifying Project Structure"

  if [ ! -f "package.json" ]; then
    print_error "package.json not found in current directory"
    echo "Please make sure you're running this script from the project root directory"
    exit 1
  fi

  print_success "Project structure verified"
  echo ""
}

# Install dependencies
install_dependencies() {
  print_header "Installing Dependencies"

  print_info "Running 'npm install'..."
  npm install

  print_success "Dependencies installed successfully"
  echo ""
}

# Show project info
show_project_info() {
  print_header "Project Setup Complete!"

  echo ""
  print_success "NN Tech Wordle Game is ready to run"
  echo ""
  echo -e "${BLUE}Next Steps:${NC}"
  echo ""
  echo "1. Start the development server:"
  echo -e "   ${YELLOW}npm run dev${NC}"
  echo ""
  echo "2. Open your browser and visit:"
  echo -e "   ${YELLOW}http://localhost:3000${NC}"
  echo ""
  echo -e "${BLUE}Other available commands:${NC}"
  echo -e "   ${YELLOW}npm run build${NC}    - Create production build"
  echo -e "   ${YELLOW}npm start${NC}        - Run production server"
  echo -e "   ${YELLOW}npm run lint${NC}     - Run ESLint checks"
  echo ""
  echo -e "${BLUE}For more information, see README.md${NC}"
  echo ""
}

# Main script
main() {
  print_header "NN Tech Wordle Game - Automated Setup"
  echo "This script will set up the Wordle game project on your machine"
  echo ""

  # Check prerequisites
  check_prerequisites

  # Verify project structure
  verify_project

  # Install dependencies
  install_dependencies

  # Show success message
  show_project_info
}

# Run main function
main "$@"

