package com.nn.wordle.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "player")
public class Player {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "linkedin_url", nullable = false, length = Integer.MAX_VALUE)
    private String linkedinUrl;

    @Column(name = "conference_name", nullable = false)
    private String conferenceName;

    @Column(name = "sign_up", nullable = false)
    private LocalDateTime signUp;

    @Column(name = "last_scan", nullable = false)
    private LocalDateTime lastScan;

    public Player() {
    }

    public Player(
        String name,
        String linkedinUrl,
        String conferenceName
    ) {
        this.name = name;
        this.linkedinUrl = linkedinUrl;
        this.conferenceName = conferenceName;
        this.signUp = LocalDateTime.now();
        this.lastScan = LocalDateTime.now();
    }

    public void updateLastScan() {
        this.lastScan = LocalDateTime.now();
    }

    public void updateNickName(String name) {
        this.name = name;
        this.lastScan = LocalDateTime.now();
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLinkedinUrl() {
        return linkedinUrl;
    }

    public String getConferenceName() {
        return conferenceName;
    }

    public LocalDateTime getSignUp() {
        return signUp;
    }

    public LocalDateTime getLastScan() {
        return lastScan;
    }

}