# NN Tech Wordle Game

A modern Wordle game application built with Next.js, React, and TypeScript. Features QR code scanning, real-time gameplay, and beautiful UI with Material-UI components.

## Prerequisites

Before you begin, ensure you have the following installed on your machine:

- **Node.js** (version 16 or higher, version 22 recommended)
- **npm** (comes with Node.js)

### Installing Node.js

#### Option 1: Download from nodejs.org (Recommended)
Visit [https://nodejs.org/](https://nodejs.org/) and download Node.js v22 LTS or the latest stable version.

#### Option 2: Using Package Managers

**macOS (using Homebrew):**
```bash
brew install node@22
```

**Windows (using Chocolatey):**
```powershell
choco install nodejs --version=22.0.0
```

**Linux (Ubuntu/Debian):**
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs
```

**Linux (Fedora):**
```bash
sudo dnf install nodejs npm
```

## Installation

### Quick Start (Using Setup Scripts)

This is the easiest way to set up the project. The setup scripts handle everything automatically:

#### Step 1: Transfer Project Files

Copy the entire project folder to your machine using:
- USB drive
- Cloud storage (Google Drive, OneDrive, Dropbox, etc.)
- File transfer tools
- SCP/SFTP
- Any other file transfer method

#### Step 2: Run the Setup Script

Navigate to the project directory and run the appropriate script for your operating system:

**For macOS / Linux:**

```bash
# Make the script executable (first time only)
chmod +x setup.sh

# Run the setup script
./setup.sh
```

**For Windows (PowerShell):**

```powershell
# Open PowerShell and navigate to the project directory, then run:
.\setup.ps1

# If you get an execution policy error, run this first:
powershell -ExecutionPolicy Bypass -File setup.ps1
```

**For Windows (Command Prompt / Batch):**

```cmd
# Simply run the batch file:
setup.bat
```

The script will automatically:
- ✅ Check all prerequisites (Node.js, npm)
- ✅ Verify project structure
- ✅ Install all dependencies
- ✅ Display next steps

### Manual Setup

If you prefer to set up manually:

1. **Install Dependencies**

```bash
npm install
```

This will install all required dependencies specified in `package.json`.

## Running the Project

### Development Mode

To run the project in development mode with hot reloading:

```bash
npm run dev
```

The application will start on `http://localhost:3000` by default.

### Production Build

To create an optimized production build:

```bash
npm run build
```

To start the production server:

```bash
npm start
```

## Available Scripts

- **`npm run dev`** - Starts the development server with hot module reloading
- **`npm run build`** - Creates an optimized production build
- **`npm start`** - Runs the production server
- **`npm run lint`** - Runs ESLint to check code quality

## Setup Scripts

This project includes automated setup scripts for different operating systems. Simply run them from the project directory after copying the files to your machine:

- **`setup.sh`** - Bash script for macOS and Linux
- **`setup.ps1`** - PowerShell script for Windows
- **`setup.bat`** - Batch script for Windows (alternative)

These scripts automatically:
- ✅ Verify all prerequisites (Node.js and npm)
- ✅ Validate project structure
- ✅ Install all dependencies
- ✅ Display setup completion and next steps

**No parameters needed** - just copy the project folder to another machine and run the appropriate script!

## Project Structure

```
src/
├── components/        # Reusable React components
│   ├── button/       # Custom button component
│   ├── decor/        # Decorative components (e.g., EmojiEmitter)
│   ├── game/         # Main game component
│   ├── guess/        # Guess display component
│   ├── header/       # Header component
│   ├── home/         # Home page components
│   ├── letter/       # Letter tile component
│   └── scanner/      # QR code scanner components
├── hooks/            # Custom React hooks
├── pages/            # Next.js pages
├── styles/           # Global styles and theme configuration
├── utils/            # Utility functions and data
└── ...

public/              # Static assets
└── fonts/           # Custom fonts
└── images/          # Images and logos

```

## Technologies Used

- **Next.js** (v16.0.4) - React framework for production
- **React** (v18) - JavaScript library for building user interfaces
- **TypeScript** (v5) - Typed superset of JavaScript
- **Material-UI** (@mui/material) - UI component library
- **TSParticles** - Particle animation system
- **html5-qrcode** - QR code scanning library
- **React Countdown** - Countdown timer component
- **Emotion** - CSS-in-JS styling solution

## Development Tools

- **ESLint** - Code linting and quality checking
- **Prettier** - Code formatting

## Browser Support

The project uses modern ES2017 JavaScript features and is compatible with all modern browsers (Chrome, Firefox, Safari, Edge).

## Troubleshooting

### Port 3000 Already in Use

If port 3000 is already in use, you can run the dev server on a different port:

```bash
npm run dev -- -p 3001
```

### Module Not Found Errors

If you encounter module not found errors, try clearing the Next.js cache and reinstalling dependencies:

```bash
rm -rf .next node_modules
npm install
```

### Build Issues

Ensure you're using a compatible Node.js version. Check your Node.js version:

```bash
node --version
```

## Contributing

Please follow the existing code style and ESLint configuration when contributing to this project.

## License

This project is private software developed by NN Technologies.

---

For more information or support, please contact the development team.

