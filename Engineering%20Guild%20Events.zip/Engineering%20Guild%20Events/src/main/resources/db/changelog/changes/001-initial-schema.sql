
CREATE TABLE player
(
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NULL,
    linkedin_url TEXT NOT NULL,
    conference_name VARCHAR(255) NOT NULL,
    sign_up timestamp NOT NULL,
    last_scan timestamp NOT NULL
);

create table game_result
(
    id SERIAL PRIMARY KEY ,
    player_id INT NOT NULL,
    game_day date NOT NULL,
    game_time time NOT NULL,
    score bigint NOT NULL,
    guessed boolean NOT NULL,
    FOREIGN KEY (player_id) REFERENCES player(id)
)

