package com.nn.wordle.services;

import com.nn.wordle.controller.GameController;
import com.nn.wordle.entities.GameResult;
import com.nn.wordle.entities.Player;
import com.nn.wordle.repositories.GameRepository;
import com.nn.wordle.repositories.PlayerRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class GameService {

    private static final Logger LOGGER = LoggerFactory.getLogger(GameService.class);

    private static final Pattern LINKEDIN_URL_NAME_PATTERN = Pattern.compile("https://www.linkedin.com/in/(?<name>[a-zA-Z-]+)");

    private final GameRepository gameRepository;
    private final PlayerRepository playerRepository;
    private final String conferenceName;

    public GameService(GameRepository gameRepository,
                       PlayerRepository playerRepository,
                       @Value("${game.conference}") String conferenceName) {
        this.gameRepository = gameRepository;
        this.playerRepository = playerRepository;
        this.conferenceName = conferenceName;
    }

    @Transactional(readOnly = true)
    public GameController.Dashboard getDashboard() {
        var gameResults = gameRepository.findTop15ByGuessedTrueAndGameDayOrderByScoreAsc(LocalDate.now());
        var dashboardEntries = gameResults.stream().map(this::buildFromResults).toList();
        var totalGamesPlayedTillNow = playerRepository.countPlayerByLastScanIsBetween(LocalDate.now().atStartOfDay(),
                LocalDateTime.of(LocalDate.now(),LocalTime.MAX));
        return new GameController.Dashboard(dashboardEntries, totalGamesPlayedTillNow);
    }


    @Transactional(readOnly = true)
    public GameController.Dashboard getSimplifiedDashboard() {
        var gameResults = gameRepository.findTop4ByGuessedTrueAndGameDayOrderByScoreAsc(LocalDate.now());
        var dashboardEntries = gameResults.stream().map(this::buildFromResults).toList();
        var totalGamesPlayedTillNow = playerRepository.countPlayerByLastScanIsBetween(LocalDate.now().atStartOfDay(),
                LocalDateTime.of(LocalDate.now(),LocalTime.MAX));
        return new GameController.Dashboard(dashboardEntries, totalGamesPlayedTillNow);
    }

    private GameController.DashboardEntry buildFromResults(GameResult gameResult) {
        Player player = gameResult.getPlayer();
        return new GameController.DashboardEntry(
            player.getName(),
            gameResult.getScore(),
            player.getLinkedinUrl()
        );
    }

    @Transactional
    public GameResult saveGame(Long playerId, GameController.InputGameResult inputGameResult) throws PlayerNotFoundException {
        var player = playerRepository.findById(playerId);
        if (player.isEmpty()) {
            throw new PlayerNotFoundException("Player not found with id: " + playerId);
        }
        updateNickName(player.get(), inputGameResult.nickName());
        return handleGameResult(inputGameResult, player.get());
    }

    @Transactional
    public Optional<Player> createPlayer(String linkedInUrl) {
        var existingPlayer = playerRepository.findByLinkedinUrl(linkedInUrl);
        if (existingPlayer.isEmpty()) {
            return Optional.of(insertNewPlayer(linkedInUrl));
        } else {
            return existingPlayer.map(this::updateLastScanTime);
        }
    }

    private Player updateLastScanTime(Player existingPlayer) {
        existingPlayer.updateLastScan();
        Player updatedPlayer = playerRepository.save(existingPlayer);
        LOGGER.info("Player with id [{}] have been updated its last scan", updatedPlayer.getId());
        return updatedPlayer;
    }

    private Player insertNewPlayer(String linkedInUrl) {
        Player savedPlayer = playerRepository.save(buildPlayerFromLinkedInUrl(linkedInUrl));
        LOGGER.info("New player [{}] have been inserted with id [{}]", linkedInUrl, savedPlayer.getId());
        return savedPlayer;
    }

    private Player buildPlayerFromLinkedInUrl(String linkedInUrl) {
        String name = extractName(linkedInUrl);
        return new Player(name, linkedInUrl, conferenceName);
    }

    private String extractName(String linkedInUrl) {
        //"https://www.linkedin.com/in/john-doe-356234567?fromQR=1"
        if (StringUtils.isBlank(linkedInUrl)) {
            LOGGER.warn("LinkedIn URL is blank therefore returning blank name");
            return "";
        }
        Matcher linkedInUrlMatcher = LINKEDIN_URL_NAME_PATTERN.matcher(linkedInUrl);
        if (doesLinkedInUrlContainName(linkedInUrlMatcher)) {
            String name = linkedInUrlMatcher.group("name");
            return name.replace("-", "").trim().toUpperCase(Locale.ROOT);
        }
        LOGGER.warn("LinkedIn URL did not match expected regex pattern therefore returning blank name");
        return "";
    }

    private Boolean doesLinkedInUrlContainName(Matcher linkedInUrlMatcher) {
        return linkedInUrlMatcher.find() && linkedInUrlMatcher.namedGroups().containsKey("name");
    }

    private void updateNickName(Player player, String nickName) {
        player.updateNickName(nickName);
        playerRepository.save(player);
    }

    @Transactional
    public Player getCurrentPlayer() {
        return playerRepository.findTopByOrderByLastScanDesc();
    }

    private GameResult handleGameResult(
        GameController.InputGameResult inputGameResult,
        Player player
    ) {
        var gameResult = gameRepository.findByPlayerAndGameDay(player, LocalDate.now());
        if (gameResult.isEmpty()) {
            return gameRepository.save(new GameResult(player, LocalDate.now(), LocalTime.now(), inputGameResult.score(), inputGameResult.guessed()));
        } else {
            return updatePreviousGameResult(LocalTime.now(), inputGameResult.score(), inputGameResult.guessed(), gameResult.get());
        }
    }

    private GameResult updatePreviousGameResult(LocalTime startTime,
                                                Long score,
                                                boolean guessed,
                                                GameResult gameResult) {
        if (isCurrentScoreBetter(score, guessed, gameResult)) {
            gameResult.updateGameResult(startTime, score, guessed);
            return gameRepository.save(gameResult);
        }
        return gameResult;
    }

    private boolean isCurrentScoreBetter(Long score,
                                         Boolean guessed,
                                         GameResult gameResult) {
        return guessed && score < gameResult.getScore();
    }

}
