#!/usr/bin/env bash

set -e

function start_application() {
    java -XX:InitialRAMPercentage=${JVM_INITIAL_PERCENTATGE} -XX:MaxRAMPercentage=${JVM_MAX_PERCENTATGE} \
         ${JAVA_OPTS} \
         -Djava.security.egd=file:/dev/./urandom \
         -jar /opt/ecaps/wordle/wordle.jar
}

start_application