package com.nn.wordle;

import com.nn.wordle.entities.GameResult;
import com.nn.wordle.entities.Player;
import com.nn.wordle.repositories.GameRepository;
import com.nn.wordle.repositories.PlayerRepository;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Disabled
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class GameRepositoryTest {

    @Autowired
    private PlayerRepository playerRepository;

    @Autowired
    private GameRepository gameRepository;

    @Autowired
    private EntityManager entityManager;

    @BeforeEach
    void setup() {
//        List<Player> existingPlayers = playerRepository.findAllByNameIn(List.of("player1", "player2", "player3", "player4"));
//        if (!existingPlayers.isEmpty()) {
//            gameRepository.deleteAllByPlayerIn(existingPlayers);
//            playerRepository.deleteAll(existingPlayers);
//            entityManager.flush();
//        }

        Player player1 = new Player("player1", "player1url", "GOTO");
        Player player2 = new Player("player2", "player2url", "GOTO");
        Player player3 = new Player("player3", "player3url", "GOTO");
        Player player4 = new Player("player4", "player4url", "GOTO");
        GameResult gameResult1 = new GameResult(player1, LocalDate.now(), LocalTime.now(), 10L, true);
        GameResult gameResult3 = new GameResult(player2, LocalDate.now(), LocalTime.now(), 10L, true);
        GameResult gameResult5 = new GameResult(player3, LocalDate.now(), LocalTime.now(), 5L, true);
        GameResult gameResult7 = new GameResult(player4, LocalDate.of(2022,1,1),LocalTime.now(), 1L, true);
        playerRepository.save(player1);
        playerRepository.save(player2);
        playerRepository.save(player3);
        playerRepository.save(player4);
        gameRepository.save(gameResult1);
//        gameRepository.save(gameResult2);
        gameRepository.save(gameResult3);
//        gameRepository.save(gameResult4);
        gameRepository.save(gameResult5);
//        gameRepository.save(gameResult6);
        gameRepository.save(gameResult7);
        entityManager.flush();
    }

    @Test
    void findCountByGameDateBetween_NoData() {
        int count = gameRepository.countByGameDay(LocalDate.of(2023, 1, 1));
        assertEquals(0, count);
    }

    @Test
    void findCountByGameDateBetween_WithData() {
        int count = gameRepository.countByGameDay(LocalDate.now());
        assertEquals(6, count);
    }
    @Test
    void findAllByGuessedTrueAndGameDateBetweenOrderByScoreAsc_WithData() {
        List<GameResult> gameResults = gameRepository.findTop4ByGuessedTrueAndGameDayOrderByScoreAsc(LocalDate.now());
        assertThat(gameResults).hasSize(4);
    }
}