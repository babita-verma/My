# Wordle Game Backend

## Table of Contents

1. [Project Description](#1-project-description)
2. [Architecture](#2-architecture)
    1. [C4 Container View](#21-container-diagram)
    2. [Entity Relationship Diagram](#22-entity-relationship-diagram)
3. [Used Technologies](#3-used-technologies)
4. [Repository Overview](#4-repository-overview)
5. [Build and deploy](#5-build-and-deploy)
    1. [How to build locally](#51-how-to-build-locally)
    2. [How to run locally](#52-how-to-run-locally)
    3. [How to test locally](#53-how-to-test-locally)
    4. [How to export data](#54-how-to-export-data)

## 1) Project description

This project will be used for backend of the [Wordle Game][introduction-01] created by Engineering Guild. The main 
requirements are:

* The main basic functionality of the game is to guess the word in 6 attempts.
* The game will be played in rounds and each round will have a winner.
* The winner will be the one who has guessed the word in minimum attempts.
* The game will have a dashboard where all the players can see the current round details and the winner of the round.
* The game will have a winner page where the winner of the round can see the details of the round he won.
* The game will have a history page where all the previous rounds and their winners can be seen.

[introduction-01]: https://en.wikipedia.org/wiki/Wordle

## 2) Architecture

To give a Wordle architecture overview a [C4 modeling][c4-01] is going to be used.

### 2.1) Container diagram

![Container Diagram][c4-02]

[PlantUML diagram can be found here][c4-03]

**Note:** [PlantUML C4 diagrams][c4-04] are used to draw the different C4 modelling views. In order to update the diagram
you could either use the [PlantUML Intellij plugin][c4-05] or just go to [PlantUML live site][c4-06].And in Mac
need to install "brew install graphviz". In Intellij, click the wrench icon on the far right of the menu panel
that contains the plantuml view and editor arrangement.Click 'Open settings'
For 'Graphviz dot executable' add /opt/homebrew/bin/dot.

[c4-01]: https://c4model.com/
[c4-02]: documentation/architecture/diagrams/images/Wordle_C4_Container.png
[c4-03]: docs/architecture/diagrams/plantuml/ecaps_c4_container.puml
[c4-04]: https://github.com/plantuml-stdlib/C4-PlantUML
[c4-05]: https://plugins.jetbrains.com/plugin/7017-plantuml-integration
[c4-06]: https://www.plantuml.com/plantuml/uml

### 2.2) Entity Relationship Diagram

![Entity Relationship Diagram][er-01]

[er-01]: documentation/architecture/diagrams/images/Wordle_Entity_Relationship.png

## 3) Used technologies

The following technologies are used to implement, build and run this project:

* [Docker][tech-01]: used to define the containers that will run the SpringBoot applications. Docker definitions can be
found [here][tech-02].
* [Gradle][tech-03]: used to automate building, testing, and deployment of software from information in build scripts.
The build script can be found [here][tech-04].
* [SpringBoot][tech-05]: used to build in a more convenient way a web application with plenty of production grade
  functionality built-in.
* [PostgreSQL][tech-06]: it's an open source object-relational database system used to store the data.
* [PgAdmin][tech-07]: it's an open source web-based admin console for PostgreSQL.

[tech-01]: https://docs.docker.com/engine/reference/builder/
[tech-02]: infra/docker
[tech-03]: https://gradle.org/
[tech-04]: build.gradle
[tech-05]: https://spring.io/projects/spring-boot
[tech-06]: https://www.postgresql.org/
[tech-07]: https://www.pgadmin.org/

3.1 Install Java version 21.0.2 (not lower but preferrable 21.x )

3.2 Set JAVA_HOME environment variable

3.3 Add %JAVA_HOME%\bin to PATH

3.4 Install Gradle version 8.7 (now higher)

3.5 Add Gradle to PATH

3.6 Install Docker Desktop

3.7 Start Docker Desktop


## 4) Repository overview

This project is structured using the following directories:

1) [**documentation**][repository-overview-01]: contains documentation related files like diagrams.
2) [**infra**][repository-overview-02]: contains infrastructure as code like Dockerfile definitions.
3) [**src**][repository-overview-03]: contains the Wordle backend application's source code.

[repository-overview-01]: documentation
[repository-overview-02]: infra
[repository-overview-03]: src

## 5) Build and deploy

### 5.1) How to build locally

This application is build using Gradle so in order to build locally we need to run the Gradle command:

```shell
gradlew build
```

That command will execute all tests and generate a jar file which is the backend Java runnable. [Gradle][how-to-build-01] 
is configured to copy the generated jar file into [Docker context folder][how-to-build-02].

[how-to-build-01]: build.gradle
[how-to-build-02]: infra/docker/wordle/config

### 5.2) How to run locally

As we mentioned before running the application we need the database to be up and running. We can run it in different 
ways:

#### 5.2.1

1) Start database and database admin console using Docker/Podman and run Wordle backend using an IDE

* Using docker-compose:

```shell
cd infra/docker-compose
docker-compose up -d --build wordle_db wordle_db_admin
```

**Note:** remember to replace `{path_where_to_export_data}` and `{path_where_to_keep_database_data}` by the path of 
choice to your local system. Also remember to change the environment variable `GAME_CONFERENCE` value to the right 
conference name.

#### 5.2.2

* Using plain Docker/Podman commands:

First we need to create a network and volume:

```shell
podman network create wordle-network
podman volume create wordle-db-data
```

```shell
docker network create wordle-network
docker volume create wordle-db-data
```

Then we can just run the database and admin console:

```shell
podman run -d --name wordle_db --network wordle-network -p 5432:5432 -v wordle_db_data:/var/lib/postgresql/data -v {path_where_to_export_data}:/tmp/export-data -e POSTGRES_PASSWORD=S3cret@!007 -e POSTGRES_USER=nnwordle -e POSTGRES_DB=wordle postgres:16-alpine
podman run -d --name wordle_db_admin --network wordle-network -p 8097:80 -e PGADMIN_DEFAULT_EMAIL=wordle@nn.com -e PGADMIN_DEFAULT_PASSWORD=password -d dpage/pgadmin4:8.6
```

```shell
docker run -d --name wordle_db --network wordle-network -p 5432:5432 -v wordle_db_data:/var/lib/postgresql/data -v {path_where_to_export_data}:/tmp/export-data -e POSTGRES_PASSWORD=S3cret@!007 -e POSTGRES_USER=nnwordle -e POSTGRES_DB=wordle postgres:16-alpine
docker run -d --name wordle_db_admin --network wordle-network -p 8097:80 -e PGADMIN_DEFAULT_EMAIL=wordle@nn.com -e PGADMIN_DEFAULT_PASSWORD=password -d dpage/pgadmin4:8.6
```

**Note:** remember to replace `{path_where_to_export_data}` and `{path_where_to_keep_database_data}` by the path of 
choice to your local system.

Once the database is up and running we can just run the backend from the IDE of choice.

**Note:** remember to change the backend property `game.conference` value to the right conference name. You either 
change it in the [properties file][how-to-run-01] or pass it as environment variable to IDE run configuration 
`-Dgame.conference={conference_name}`

[how-to-run-01]: src/main/resources/application.properties

2) Run everything using Docker/Podman

* Using docker-compose:

```shell
cd infra/docker-compose
docker-compose up -d
```

**Note:** remember to replace `{path_where_to_export_data}` and `{path_where_to_keep_database_data}` by the path of 
choice to your local system. Also remember to change the environment variable `GAME_CONFERENCE` value to the right
conference name.

* Using plain Docker/Podman commands:

First, we need to build the Wordle backend image:

```shell
cd {wordle_project_location}/infra/docker/wordle
podman build -t local/nn-wordle:1.0.0 .
```

```shell
cd {wordle_project_location}/infra/docker/wordle
docker build -t local/nn-wordle:1.0.0 .
```

Next, we need to create a network and volume:

```shell
podman network create wordle-network
podman volume create wordle-db-data
```

```shell
docker network create wordle-network
docker volume create wordle-db-data
```

Then we can just run the database and admin console:

```shell
podman run -d --name wordle_db --network wordle-network -p 5432:5432 -v wordle_db_data:/var/lib/postgresql/data -v {path_where_to_export_data}:/tmp/export-data -e POSTGRES_PASSWORD=S3cret@!007 -e POSTGRES_USER=nnwordle -e POSTGRES_DB=wordle postgres:16-alpine
podman run -d --name wordle_db_admin --network wordle-network -p 8097:80 -e PGADMIN_DEFAULT_EMAIL=wordle@nn.com -e PGADMIN_DEFAULT_PASSWORD=password -d dpage/pgadmin4:8.6
```

```shell
docker run -d --name wordle_db --network wordle-network -p 5432:5432 -v wordle_db_data:/var/lib/postgresql/data -v {path_where_to_export_data}:/tmp/export-data -e POSTGRES_PASSWORD=S3cret@!007 -e POSTGRES_USER=nnwordle -e POSTGRES_DB=wordle postgres:16-alpine
docker run -d --name wordle_db_admin --network wordle-network -p 8097:80 -e PGADMIN_DEFAULT_EMAIL=wordle@nn.com -e PGADMIN_DEFAULT_PASSWORD=password -d dpage/pgadmin4:8.6
```

**Note:** remember to replace `{path_where_to_export_data}` and `{path_where_to_keep_database_data}` by the path of 
choice to your local system. Also remember to change the environment variable `GAME_CONFERENCE` value to the right
conference name.

Finally we run the Wordle backend image:

```shell
podman run -d --name wordle_backend --network wordle-network -p 8080:8080 -e GAME_CONFERENCE=Teqnation -e SPRING_DATASOURCE_URL=jdbc:postgresql://wordle_db:5432/wordle local/nn-wordle:1.0.0
```

```shell
docker run -d --name wordle_backend --network wordle-network -p 8080:8080 -e GAME_CONFERENCE=Teqnation -e SPRING_DATASOURCE_URL=jdbc:postgresql://wordle_db:5432/wordle local/nn-wordle:1.0.0
```

**Note:** remember to change the environment variable `GAME_CONFERENCE` value to the right conference name.

### 5.3) How to test locally

Once everything is deployed we can find:

* Wordle backend [here][test-01] (please notice that there is no UI but only exposes API endpoints so you will see an error pages)
* Database admin console [here][test-02].

[test-01]: http://localhost:8080/
[test-02]: http://localhost:8097/

In order to test if Wordle backend API's work properly we can use `cURL` command to create a player:

```shell
curl -vv -H "Content-Type: application/json" -d "{ \"linkedInUrl\": \"https://www.linkedin.com/in/john-doe-356234567?fromQR=1\" }" http://localhost:8080/api/games/player
```

To fetch the latest scanned player:

```shell
curl -vv http://localhost:8080/api/games/player/last
```

To record a game end result:

```shell
curl -vv -H "Content-Type: application/json" -d "{ \"nickName\": \"Peter\", \"startTime\": \"16:55:48.8986978\", \"score\": 101, \"guessed\": true }" http://localhost:8080/api/games/player/15/end
```

To fetch dashboard with top 10 players:

```shell
curl -vv http://localhost:8080/api/games/dashboard
```

### 5.4) How to export data

First exec into database container:

```shell
podman exec -it wordle_db bash
```

```shell
docker exec -it wordle_db bash
```

Once into the container we export the data as CSV:

```shell
psql -U nnwordle wordle -c "COPY (SELECT * FROM player) TO STDOUT DELIMITER ',' CSV HEADER" > /tmp/export-data/player.csv
psql -U nnwordle wordle -c "COPY (SELECT * FROM game_result) TO STDOUT DELIMITER ',' CSV HEADER" > /tmp/export-data/gameresult.csv
```
