package com.nn.wordle.repositories;

import com.nn.wordle.entities.Player;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.Optional;

public interface PlayerRepository extends JpaRepository<Player, Long>{

    Optional<Player> findByLinkedinUrl(String linkedinUrl);

    Player findTopByOrderByLastScanDesc();

    long countPlayerByLastScanIsBetween(LocalDateTime start, LocalDateTime end);

}
