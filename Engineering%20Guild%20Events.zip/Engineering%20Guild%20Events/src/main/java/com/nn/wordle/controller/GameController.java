package com.nn.wordle.controller;


import com.nn.wordle.entities.GameResult;
import com.nn.wordle.entities.Player;
import com.nn.wordle.services.GameService;
import com.nn.wordle.services.PlayerNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/games")
public class GameController {

    private static final Logger LOGGER = LoggerFactory.getLogger(GameController.class);

    private final GameService gameService;

    public GameController(GameService gameService) {
        this.gameService = gameService;
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping(value = "/player", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Optional<Player>> addPlayer(@RequestBody PlayerLinkedUrl playerLinkedUrl) {
        String fullUrl = playerLinkedUrl.linkedInUrl();
        String cleanUrl = fullUrl.contains("?") ? fullUrl.substring(0, fullUrl.indexOf("?")) : fullUrl;
        var player = gameService.createPlayer(cleanUrl);
        return ResponseEntity.status(HttpStatus.CREATED).body(player);
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/player/last")
    public ResponseEntity<Player> getCurrentPlayer() {
        var player = gameService.getCurrentPlayer();
        return ResponseEntity.ok().body(player);
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @PostMapping("/player/{playerId}/end")
    public ResponseEntity<GameResult> finishGame(@PathVariable Long playerId, @RequestBody InputGameResult inputGameResult) {
        try {
            GameResult gameResult = gameService.saveGame(playerId, inputGameResult);
            return ResponseEntity.status(HttpStatus.CREATED).body(gameResult);
        } catch (PlayerNotFoundException e) {
            LOGGER.warn("Player with id [{}] not found", playerId);
            return ResponseEntity.notFound().build();
        }
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/dashboard")
    public ResponseEntity<Dashboard> getDashboard() {
        var dashboard = gameService.getDashboard();
        return ResponseEntity.ok().body(dashboard);
    }

    @CrossOrigin(origins = "http://localhost:3000")
    @GetMapping("/simplified-dashboard")
    public ResponseEntity<Dashboard> getSimplifiedDashboard() {
        var dashboard = gameService.getSimplifiedDashboard();
        return ResponseEntity.ok().body(dashboard);
    }

    public record Dashboard(List<DashboardEntry> dashboardEntries, long totalGames) {}
    public record DashboardEntry(String nickName, Long score, String linkedInUrl) {}

    record PlayerLinkedUrl(String linkedInUrl) {}

    public record InputGameResult(String nickName, Long score, boolean guessed) {}

}