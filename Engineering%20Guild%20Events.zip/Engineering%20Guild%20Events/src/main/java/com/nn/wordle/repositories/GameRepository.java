package com.nn.wordle.repositories;

import com.nn.wordle.entities.GameResult;
import com.nn.wordle.entities.Player;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface GameRepository extends JpaRepository<GameResult, Integer> {

    int countByGameDay(LocalDate gameDay);

    Optional<GameResult> findByPlayerAndGameDay(Player player, LocalDate date);

    List<GameResult> findTop15ByGuessedTrueAndGameDayOrderByScoreAsc(LocalDate gameDay);
    List<GameResult> findTop4ByGuessedTrueAndGameDayOrderByScoreAsc(LocalDate gameDay);

}
